
'use client'

import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { useInView } from 'react-intersection-observer'
import { Target, Database, Lightbulb, Cog, Rocket } from 'lucide-react'

const MethodologySection = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const pillars = [
    {
      letter: 'A',
      title: 'ANÁLISE PROFUNDA',
      subtitle: 'Diagnóstico Sistêmico',
      icon: Target,
      description: 'Entendemos onde estão os gargalos e as oportunidades ocultas em seu negócio. Analisamos a lógica que sustenta (ou trava) o crescimento atual.',
      features: ['Diagnóstico sistêmico completo', 'Identificação de gargalos e oportunidades', 'Análise da lógica de crescimento atual']
    },
    {
      letter: 'D',
      title: 'DIRECIONAMENTO DE VALOR',
      subtitle: 'Reposicionamento Estratégico',
      icon: Database,
      description: 'Redesenhamos o posicionamento da sua marca e a proposta de valor. Trazemos clareza sobre o que vender, para quem, como e por quê.',
      features: ['Reposicionamento de marca', 'Proposta de valor clara', 'Definição estratégica do negócio']
    },
    {
      letter: 'I',
      title: 'IMPULSO COMERCIAL',
      subtitle: 'Comercial, Marketing e Margem',
      icon: Lightbulb,
      description: 'Organizamos funis, canais e estratégias para vender com consistência e margem. Aplicamos rotinas práticas para a geração de demanda e a ativação do time.',
      features: ['Organização de funis de venda', 'Estratégias de geração de demanda', 'Ativação e treinamento do time']
    },
    {
      letter: 'T',
      title: 'TRAVE MESTRA OPERACIONAL',
      subtitle: 'Operação e Liderança',
      icon: Cog,
      description: 'Reestruturamos fluxos e papéis dentro da sua empresa, revisando ritos de gestão e indicadores-chave. A liderança passa a operar com foco, disciplina e alinhamento.',
      features: ['Reestruturação de fluxos operacionais', 'Revisão de ritos de gestão', 'Indicadores-chave de performance']
    },
    {
      letter: 'I',
      title: 'IMPLEMENTAÇÃO COM RITMO',
      subtitle: 'Execução com Cadência',
      icon: Rocket,
      description: 'Acompanhamos a execução com ferramentas de foco e rotina semanal/mensal para garantir que o plano saia do papel e os resultados se sustentem no tempo.',
      features: ['Ferramentas de foco e execução', 'Rotinas semanais e mensais', 'Acompanhamento de resultados sustentáveis']
    }
  ]

  return (
    <section id="methodology" className="py-20 bg-white">
      <div className="section-container">
        <div ref={ref}>
          
          {/* Section Header */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-6 font-poppins">
              Metodologia <span className="text-purple-600">ADITI™</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Nossa metodologia proprietária foi construída com experiência corporativa e traduz grandes estratégias em rotinas simples e acionáveis. O método ADITI™ é a nossa arquitetura de crescimento empresarial, aplicável a todas as nossas frentes, para negócios que precisam evoluir com clareza, margem e cadência.
            </p>
          </motion.div>

          {/* ADITI Letters Visual */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={inView ? { opacity: 1, scale: 1 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="flex justify-center items-center mb-16"
          >
            <div className="flex space-x-2 sm:space-x-4 text-6xl sm:text-8xl font-bold font-poppins">
              {['A', 'D', 'I', 'T', 'I']?.map((letter, index) => (
                <motion.span
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={inView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.5, delay: 0.4 + index * 0.1 }}
                  className="bg-gradient-to-br from-purple-600 to-blue-600 bg-clip-text text-transparent"
                >
                  {letter}
                </motion.span>
              ))}
            </div>
          </motion.div>

          {/* Pillars Grid */}
          <div className="grid lg:grid-cols-3 gap-8">
            {pillars?.map((pillar, index) => {
              const IconComponent = pillar?.icon
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  animate={inView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.8, delay: 0.6 + index * 0.1 }}
                  className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 group hover:-translate-y-2"
                >
                  
                  {/* Header */}
                  <div className="flex items-center space-x-4 mb-6">
                    <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-blue-500 rounded-full flex items-center justify-center text-2xl font-bold text-white font-poppins group-hover:scale-110 transition-transform duration-300">
                      {pillar?.letter}
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-gray-900 font-poppins">
                        {pillar?.title}
                      </h3>
                      <p className="text-purple-600 font-medium">{pillar?.subtitle}</p>
                    </div>
                  </div>

                  {/* Icon */}
                  <div className="flex justify-center mb-6">
                    <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center">
                      {IconComponent && <IconComponent className="w-6 h-6 text-purple-600" />}
                    </div>
                  </div>

                  {/* Description */}
                  <p className="text-gray-700 leading-relaxed mb-6">
                    {pillar?.description}
                  </p>

                  {/* Features */}
                  <ul className="space-y-2">
                    {pillar?.features?.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center space-x-3">
                        <div className="w-4 h-4 bg-gradient-to-br from-purple-500 to-blue-500 rounded-full flex items-center justify-center flex-shrink-0">
                          <div className="w-1.5 h-1.5 bg-white rounded-full"></div>
                        </div>
                        <span className="text-sm text-gray-600">{feature}</span>
                      </li>
                    )) ?? []}
                  </ul>

                </motion.div>
              )
            })}
          </div>

          {/* Bottom CTA */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 1.2 }}
            className="text-center mt-16"
          >
            <div className="bg-white rounded-2xl p-8 shadow-lg max-w-2xl mx-auto">
              <h3 className="text-2xl font-bold text-gray-900 mb-4 font-poppins">
                Pronto para transformar sua empresa?
              </h3>
              <p className="text-gray-600 mb-6">
                Descubra como nossa metodologia ADITI™ pode acelerar sua transformação digital 
                com resultados mensuráveis em até 90 dias.
              </p>
              <button 
                onClick={() => document.getElementById('cta')?.scrollIntoView({ behavior: 'smooth' })}
                className="bg-gradient-to-r from-purple-600 to-blue-600 text-white px-8 py-4 rounded-full font-semibold hover:shadow-lg transition-all duration-300 hover:scale-105"
              >
                Solicitar Análise Gratuita
              </button>
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  )
}

export default MethodologySection
