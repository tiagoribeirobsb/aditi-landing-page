
'use client'

import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { useInView } from 'react-intersection-observer'
import { Star, Quote, TrendingUp, Users, Globe, Clock } from 'lucide-react'

const SocialProofSection = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const [counters, setCounters] = useState({
    revenue: 0,
    automation: 0,
    countries: 0,
    noshow: 0
  })

  useEffect(() => {
    if (inView) {
      const duration = 2000
      const steps = 50
      const stepDuration = duration / steps

      const targets = {
        revenue: 60,
        automation: 80,
        countries: 15,
        noshow: 72
      }

      let step = 0
      const interval = setInterval(() => {
        step++
        const progress = step / steps

        setCounters({
          revenue: Math.floor(targets.revenue * progress),
          automation: Math.floor(targets.automation * progress),
          countries: Math.floor(targets.countries * progress),
          noshow: Math.floor(targets.noshow * progress)
        })

        if (step >= steps) {
          clearInterval(interval)
        }
      }, stepDuration)

      return () => clearInterval(interval)
    }
  }, [inView])

  const stats = [
    {
      icon: TrendingUp,
      value: `+R$ ${counters.revenue} milhões`,
      label: 'em vendas geradas',
      color: 'from-green-500 to-emerald-600'
    },
    {
      icon: Users,
      value: `+${counters.automation}%`,
      label: 'de tarefas automatizadas',
      color: 'from-purple-500 to-pink-600'
    },
    {
      icon: Globe,
      value: 'Clientes no Brasil, Portugal,',
      label: 'EUA e Espanha',
      color: 'from-blue-500 to-cyan-600'
    },
    {
      icon: Clock,
      value: `Redução de no-show em ${counters.noshow}%`,
      label: 'nas operações comerciais',
      color: 'from-orange-500 to-red-600'
    }
  ]

  const testimonials = [
    {
      name: 'Diretor Comercial',
      position: 'Empresa XYZ',
      company: '',
      content: 'A Aditi foi o divisor de águas na nossa estrutura de vendas.',
      rating: 5,
      results: ''
    },
    {
      name: 'COO',
      position: 'Startup de Serviços',
      company: '',
      content: 'Implementamos a IA Bridge e cortamos 30 horas semanais de tarefas manuais.',
      rating: 5,
      results: '30h menos de trabalho manual'
    }
  ]

  return (
    <section id="social-proof" className="py-20 bg-white">
      <div className="section-container">
        <div ref={ref}>
          
          {/* Section Header */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-6 font-poppins">
              Resultados que constroem <span className="text-purple-600">confiança.</span>
            </h2>
          </motion.div>

          {/* Stats Grid */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="grid md:grid-cols-4 gap-8 mb-20"
          >
            {stats?.map((stat, index) => {
              const IconComponent = stat?.icon
              return (
                <div 
                  key={index}
                  className="border border-gray-200 rounded-2xl p-8 hover:border-gray-300 transition-all duration-300 text-center group"
                >
                  <div className={`w-16 h-16 bg-gradient-to-br ${stat?.color} rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300`}>
                    {IconComponent && <IconComponent className="w-8 h-8 text-white" />}
                  </div>
                  <h3 className="text-3xl font-bold text-gray-900 mb-2 font-poppins">{stat?.value}</h3>
                  <p className="text-gray-600 font-medium">{stat?.label}</p>
                </div>
              )
            })}
          </motion.div>

          {/* Testimonials */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="grid lg:grid-cols-3 gap-8"
          >
            {testimonials?.map((testimonial, index) => (
              <div 
                key={index}
                className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 group hover:-translate-y-2"
              >
                
                {/* Quote Icon */}
                <div className="flex justify-center mb-6">
                  <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                    <Quote className="w-6 h-6 text-purple-600" />
                  </div>
                </div>

                {/* Stars */}
                <div className="flex justify-center mb-4 space-x-1">
                  {[...Array(testimonial?.rating || 0)]?.map((_, starIndex) => (
                    <Star key={starIndex} className="w-5 h-5 text-yellow-400 fill-current" />
                  ))}
                </div>

                {/* Content */}
                <p className="text-gray-700 text-center mb-6 leading-relaxed">
                  "{testimonial?.content}"
                </p>

                {/* Results Badge */}
                <div className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-full px-4 py-2 text-center mb-6">
                  <span className="text-sm font-semibold text-purple-600">{testimonial?.results}</span>
                </div>

                {/* Author */}
                <div className="text-center border-t pt-6">
                  <h4 className="font-bold text-gray-900 mb-1">{testimonial?.name}</h4>
                  <p className="text-sm text-gray-600 mb-1">{testimonial?.position}</p>
                  <p className="text-xs text-purple-600 font-medium">{testimonial?.company}</p>
                </div>

              </div>
            ))}
          </motion.div>

          {/* Bottom CTA */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="text-center mt-16"
          >
            <div className="bg-gradient-to-r from-purple-600 to-blue-600 rounded-2xl p-8 text-white max-w-2xl mx-auto">
              <h3 className="text-2xl font-bold mb-4 font-poppins">
                Seja o próximo case de sucesso!
              </h3>
              <p className="mb-6 opacity-90">
                Junte-se aos nossos clientes que já transformaram seus negócios 
                e estão colhendo resultados extraordinários.
              </p>
              <button 
                onClick={() => document.getElementById('cta')?.scrollIntoView({ behavior: 'smooth' })}
                className="bg-white text-purple-600 px-8 py-4 rounded-full font-semibold hover:shadow-lg transition-all duration-300 hover:scale-105"
              >
                Quero Meus Resultados
              </button>
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  )
}

export default SocialProofSection
